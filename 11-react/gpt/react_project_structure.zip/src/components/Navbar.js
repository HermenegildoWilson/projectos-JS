import React from "react";

function Navbar() {
  return (
    <nav>
      <h2>Meu App</h2>
    </nav>
  );
}

export default Navbar;