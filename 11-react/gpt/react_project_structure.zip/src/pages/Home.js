import React from "react";
import Button from "../components/Button";

function Home() {
  return (
    <div>
      <h1>Bem-vindo ao React!</h1>
      <Button text="Clique Aqui" />
    </div>
  );
}

export default Home;